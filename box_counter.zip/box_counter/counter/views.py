import fitz  # PyMuPDF
import numpy as np
import cv2
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

def index(request):
    """Renders the upload form."""
    return render(request, 'index.html')  # Ensure the path matches your template


# def process_file(request):
#     if request.method == 'POST':
#         uploaded_file = request.FILES['file']
#         filename = uploaded_file.name.lower()
#
#         if filename.endswith('.pdf'):
#             pdf_bytes = uploaded_file.read()
#             pdf = fitz.open(stream=pdf_bytes, filetype="pdf")
#
#             # Check the number of pages
#             num_pages = pdf.page_count
#             print(f"Number of pages in PDF: {num_pages}")
#
#             if num_pages > 0:
#                 page = pdf.load_page(0)  # Load the first page
#                 pix = page.get_pixmap()  # Render page as a Pixmap
#
#                 # Print dimensions of the rendered Pixmap
#                 print(f"Rendered image size: {pix.width}x{pix.height} with {pix.n} channels")
#                 print(f"Total number of pixels: {pix.width * pix.height} and size of data: {len(pix.tobytes())}")
#
#                 # Convert Pixmap to numpy array
#                 total_pixels = pix.width * pix.height
#
#                 # Convert the Pixmap to a numpy array
#                 pix_data = np.frombuffer(pix.tobytes(), dtype=np.uint8)
#                 if pix_data.size != total_pixels * pix.n:
#                     raise ValueError(f"Data size mismatch: expected {total_pixels * pix.n}, got {pix_data.size}")
#
#                 # Reshape the array according to the number of channels
#                 if pix.n == 1:  # Grayscale
#                     image = pix_data.reshape(pix.height, pix.width)
#                 elif pix.n == 3:  # RGB
#                     image = pix_data.reshape(pix.height, pix.width, 3)
#                 elif pix.n == 4:  # RGBA
#                     image = pix_data.reshape(pix.height, pix.width, 4)
#                 else:
#                     raise ValueError("Unexpected number of channels in the rendered image.")
#
#                 # Convert RGBA to BGR for OpenCV (if necessary)
#                 if pix.n == 4:
#                     image = cv2.cvtColor(image, cv2.COLOR_RGBA2BGR)
#                 elif pix.n == 3:
#                     image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
#
#             else:
#                 return JsonResponse({'error': 'PDF is empty'}, status=400)
#
#         else:
#             # Handle image file upload
#             image_data = np.frombuffer(uploaded_file.read(), np.uint8)
#             image = cv2.imdecode(image_data, cv2.IMREAD_COLOR)
#
#         # Convert to HSV color space and create a mask for colored regions
#         hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
#         mask = cv2.inRange(hsv, (0, 100, 100), (180, 255, 255))  # Adjust range as needed
#         contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#
#         # Count boxes by filtering out small contours (noise)
#         box_count = sum(1 for cnt in contours if cv2.contourArea(cnt) > 500)
#
#         # Return the box count as a JSON response
#         return JsonResponse({'box_count': box_count})
#
#     return JsonResponse({'error': 'Invalid request method'}, status=400)

@csrf_exempt
def process_file(request):
    if request.method == 'POST':
        uploaded_file = request.FILES['file']
        filename = uploaded_file.name.lower()

        if filename.endswith('.pdf'):
            pdf_bytes = uploaded_file.read()
            pdf = fitz.open(stream=pdf_bytes, filetype="pdf")

            num_pages = pdf.page_count
            if num_pages == 0:
                return JsonResponse({'error': 'PDF is empty'}, status=400)

            # Load the first page with a zoom factor for higher resolution
            page = pdf.load_page(0)
            mat = fitz.Matrix(2, 2)  # Increase zoom for better quality
            pix = page.get_pixmap(matrix=mat)

            # Total pixels expected based on page dimensions and channels
            total_pixels = pix.width * pix.height
            print(f"Rendered image size: {pix.width}x{pix.height}, Channels: {pix.n}")
            print(f"Total Pixels: {total_pixels}, Data Length: {len(pix.tobytes())}")

            # Try to convert the pixmap to a numpy array
            try:
                pix_data = np.frombuffer(pix.tobytes(), dtype=np.uint8)

                # Dynamically reshape the array based on its size
                if pix.n == 1:  # Grayscale
                    image = pix_data.reshape(pix.height, pix.width)
                elif pix.n == 3:  # RGB
                    image = pix_data.reshape(pix.height, pix.width, 3)
                elif pix.n == 4:  # RGBA
                    image = pix_data.reshape(pix.height, pix.width, 4)
                else:
                    raise ValueError("Unexpected number of channels in the rendered image.")
            except ValueError as e:
                return JsonResponse({'error': f"Failed to process PDF: {str(e)}"}, status=500)

            # Convert RGBA to BGR if needed for OpenCV processing
            if pix.n == 4:
                image = cv2.cvtColor(image, cv2.COLOR_RGBA2BGR)
            elif pix.n == 3:
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        else:
            # Handle regular image uploads
            image_data = np.frombuffer(uploaded_file.read(), np.uint8)
            image = cv2.imdecode(image_data, cv2.IMREAD_COLOR)

        # Convert image to HSV and create a mask for colored areas
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (0, 100, 100), (180, 255, 255))

        # Find contours in the masked image
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Filter out small noise by checking contour areas
        box_count = sum(1 for cnt in contours if cv2.contourArea(cnt) > 500)

        # Return the count as a JSON response
        return JsonResponse({'box_count': box_count})

    return JsonResponse({'error': 'Invalid request method'}, status=400)
